#include <iostream>
#include <algorithm>
#include <cmath>
#include <cstdlib>

using namespace std;


double triunghi(double x, double a, double b, double c) {
    if (x <= a || x >= c) return 0.0;
    if (x == b) return 1.0;
    if (x < b) return (x - a) / (b - a);
    return (c - x) / (c - b);
}

double trapez(double x, double a, double b, double c, double d) {
    if (x < a || x > d) return 0.0;
    if (x >= b && x <= c) return 1.0;
    if (x < b) return (b == a) ? 1.0 : (x - a) / (b - a);
    return (d == c) ? 1.0 : (d - x) / (d - c);
}


double mu_u_NMa(double x) { return trapez(x, -1.0, -1.0, -0.25, -0.15); }
double mu_u_NMi(double x) { return trapez(x, -0.25, -0.15, -0.1, 0.0); }
double mu_u_ZE(double x)  { return triunghi(x, -0.1, 0.0, 0.2); }
double mu_u_PMi(double x) { return trapez(x, 0.0, 0.2, 0.6, 0.9); }
double mu_u_PMa(double x) { return trapez(x, 0.6, 0.9, 1.0, 1.0); }

int main() {
    double e, de;


    cout << "Introduceti o valoare pentru eroare (intre -1 si 1):\n";
    cout << "e = ";
    cin >> e;

    cout << "Valoarea derivatei erorii (intre -1 si 1):\n";
    cout << "de = ";
    cin >> de;


    e = max(-1.0, min(1.0, e));
    de = max(-1.0, min(1.0, de));

    // fuzzificare
    double mu_e[5];
    mu_e[0] = trapez(e, -1.0, -1.0, -0.4, -0.2);
    mu_e[1] = trapez(e, -0.3, -0.15, -0.1, 0.0);
    mu_e[2] = triunghi(e, -0.2, 0.0, 0.2);
    mu_e[3] = trapez(e, 0.0, 0.1, 0.15, 0.25);
    mu_e[4] = trapez(e, 0.15, 0.25, 1.0, 1.0);

    // gr apart. derivata erorii
    double mu_de[3];
    mu_de[0] = trapez(de, -1.0, -1.0, -0.9, 0.0);
    mu_de[1] = triunghi(de, -0.09, 0.0, 0.09);
    mu_de[2] = trapez(de, 0.0, 0.17, 1.0, 1.0);

    // part. eroare afisare
    cout << "\nAparteneta eroare.\n";
    cout << e << " apartine " << mu_e[0] << " NMa\n";
    cout << e << " apartine " << mu_e[1] << " NMi\n";
    cout << e << " apartine " << mu_e[2] << " ZE\n";
    cout << e << " apartine " << mu_e[3] << " PMi\n";
    cout << e << " apartine " << mu_e[4] << " PMa\n";

    // apart. derivata erorii afis
    cout << "\nAparteneta derivata eroare\n";
    cout << de << " apartine " << mu_de[0] << " NE\n";
    cout << de << " apartine " << mu_de[1] << " ZE\n";
    cout << de << " apartine " << mu_de[2] << " PO\n";

    // mat. gr activare
    double tabela[5][3];
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 3; j++) {
            tabela[i][j] = min(mu_e[i], mu_de[j]);
        }
    }

    // afis tabela inferenta
    cout << "\nTabela de inferenta\n";
    for (int i = 0; i < 5; i++) {
        for (int j = 0; j < 3; j++) {
            cout << tabela[i][j] << (j < 2 ? " " : "");
        }
        cout << "\n";
    }


    double act_NMa = max({tabela[0][0], tabela[0][1], tabela[1][0]});
    double act_NMi = max({tabela[0][2], tabela[1][1], tabela[2][0]});
    double act_ZE  = max({tabela[1][2], tabela[2][1], tabela[3][0]});
    double act_PMi = max({tabela[2][2], tabela[3][1], tabela[4][0]});
    double act_PMa = max({tabela[3][2], tabela[4][1], tabela[4][2]});

    // defuzificare centr. greutate
    int nr_puncte = 1001;
    double x_min = -1.0, x_max = 1.0;
    double pas = (x_max - x_min) / (nr_puncte - 1);

    double numarator = 0.0;
    double numitor = 0.0;

    for (int i = 0; i < nr_puncte; i++) {
        double x = x_min + i * pas;

        double y_NMa = min(act_NMa, mu_u_NMa(x));
        double y_NMi = min(act_NMi, mu_u_NMi(x));
        double y_ZE  = min(act_ZE,  mu_u_ZE(x));
        double y_PMi = min(act_PMi, mu_u_PMi(x));
        double y_PMa = min(act_PMa, mu_u_PMa(x));

        double mu_agregat = max({y_NMa, y_NMi, y_ZE, y_PMi, y_PMa});

        numarator += x * mu_agregat;
        numitor   += mu_agregat;
    }

    double u = (numitor == 0.0) ? 0.0 : (numarator / numitor);

    // afis u
    cout << "\nDefuzificare = " << u << "\n";

    system("pause");
    return 0;
}
